package ac.za.projects.EmployeeManagementSystem.service;

import ac.za.projects.EmployeeManagementSystem.database.EmployeeDTO;

import java.util.List;

public interface EmployeeService {
    EmployeeDTO createEmployee(EmployeeDTO employeeDTO);

    EmployeeDTO getEmployeeById(Long id);

    List<EmployeeDTO> getAllEmployee();

    EmployeeDTO updateEmployee(Long Id , EmployeeDTO updatedInfo);

    void deleteEmployee(Long Id);

}

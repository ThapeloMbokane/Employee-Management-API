package ac.za.projects.EmployeeManagementSystem.mapper;

import ac.za.projects.EmployeeManagementSystem.database.EmployeeDTO;
import ac.za.projects.EmployeeManagementSystem.entity.Employee;


public class EmployeeMapper {
    public static EmployeeDTO mapToDTO(Employee employee){

        return new EmployeeDTO(

                employee.getId(),
                employee.getName(),
                employee.getSurname(),
                employee.getEmail()
        );

    }

    public static Employee mapToEmployee(EmployeeDTO employee){

        return new Employee(

                employee.getId(),
                employee.getName(),
                employee.getSurname(),
                employee.getEmail()
        );

    }
}

package ac.za.projects.EmployeeManagementSystem.controller;

import ac.za.projects.EmployeeManagementSystem.database.EmployeeDTO;
import ac.za.projects.EmployeeManagementSystem.service.EmployeeService;
import ac.za.projects.EmployeeManagementSystem.service.implementation.EmployeeServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @PostMapping("/save")
    public ResponseEntity<EmployeeDTO> saveEmployee(@RequestBody EmployeeDTO employeeDTO){

        EmployeeDTO employee = service.createEmployee(employeeDTO);

        return new ResponseEntity<>(employee, HttpStatus.CREATED);
    }

    @GetMapping("/get/{Id}")
    public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable Long Id){

        EmployeeDTO employee = service.getEmployeeById(Id);

        return ResponseEntity.ok(employee);

    }

    @GetMapping("/all")
    public ResponseEntity<List<EmployeeDTO>> getAllEmployees(){

        List<EmployeeDTO> list = service.getAllEmployee();

        return new ResponseEntity<>(list,HttpStatus.OK);
    }

    @PutMapping("update/{Id}")
    public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable Long Id, @RequestBody EmployeeDTO updatedInfo){

        EmployeeDTO update = service.updateEmployee(Id,updatedInfo);

        return new ResponseEntity<>(update,HttpStatus.OK);

    }

    @DeleteMapping("/remove/{Id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Long Id){

        service.deleteEmployee(Id);
        String msg = "Employee Successfully Removed!!!.";
        return new ResponseEntity<>(msg,HttpStatus.OK);
        
    }

}

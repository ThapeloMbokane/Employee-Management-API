package ac.za.projects.EmployeeManagementSystem.service.implementation;

import ac.za.projects.EmployeeManagementSystem.database.EmployeeDTO;
import ac.za.projects.EmployeeManagementSystem.entity.Employee;
import ac.za.projects.EmployeeManagementSystem.exception.EmployeeNotFoundException;
import ac.za.projects.EmployeeManagementSystem.mapper.EmployeeMapper;
import ac.za.projects.EmployeeManagementSystem.repository.EmployeeRepository;
import ac.za.projects.EmployeeManagementSystem.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDTO);

        Employee savedEmployee = employeeRepository.save(employee);

        return EmployeeMapper.mapToDTO(savedEmployee);
    }

    @Override
    public EmployeeDTO getEmployeeById(Long Id) {

        String msg = "Employee Number "+Id+" does not exist";

        Employee employee = employeeRepository.findById(Id)
                .orElseThrow(() -> new EmployeeNotFoundException(msg));

        return EmployeeMapper.mapToDTO(employee);
    }

    @Override
    public List<EmployeeDTO> getAllEmployee() {

        List<Employee> employees = employeeRepository.findAll();

        return employees.stream().map((employee ) -> EmployeeMapper.mapToDTO(employee)).collect(Collectors.toList());
    }

    @Override
    public EmployeeDTO updateEmployee(Long Id, EmployeeDTO updatedInfo) {

        String msg = "Employee Number "+Id+" does not exist";

        Employee employee = employeeRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException(msg));

        employee.setName(updatedInfo.getName());
        employee.setSurname(updatedInfo.getSurname());
        employee.setEmail(updatedInfo.getEmail());

        Employee updated = employeeRepository.save(employee);

        return EmployeeMapper.mapToDTO(updated);

    }

    @Override
    public void deleteEmployee(Long Id) {
        String msg = "Employee Number "+Id+" does not exist";

        Employee employee = employeeRepository.findById(Id).orElseThrow(() -> new EmployeeNotFoundException(msg));

        employeeRepository.deleteById(Id);

    }

}
